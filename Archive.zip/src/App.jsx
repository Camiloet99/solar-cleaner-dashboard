// src/App.jsx
import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";

import AppShell from "@/components/layout/AppShell";
import { UIProvider } from "@/context/UIContext";
import { ConfigProvider } from "@/context/ConfigContext"; // ⬅️ importa el provider
import Dashboard from "@/pages/Dashboard";
import HomePage from "@/pages/HomePage";
import SessionDashboard from "@/pages/SessionDashboard";
import Configuration from "@/pages/Configuration";

// (si conectas el WS aquí)
import { connectWS, disconnectWS } from "@/services/telemetryService";

export default function App() {
  useEffect(() => {
    connectWS();
    return () => disconnectWS();
  }, []);

  return (
    <BrowserRouter>
      {/* ⬇️ ConfigProvider DEBE envolver a UIProvider */}
      <ConfigProvider>
        <UIProvider>
          <AppShell>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/sessions" element={<SessionsWrapper />} />
              <Route
                path="/session/:sessionId"
                element={<SessionDashboard />}
              />
              <Route path="/settings" element={<Configuration />} />
            </Routes>
          </AppShell>
        </UIProvider>
      </ConfigProvider>
    </BrowserRouter>
  );
}

function SessionsWrapper() {
  const navigate = useNavigate();
  return <HomePage onSelectSession={(id) => navigate(`/session/${id}`)} />;
}
