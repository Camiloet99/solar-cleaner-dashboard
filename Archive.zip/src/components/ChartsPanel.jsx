import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useConfig } from "@/context/ConfigContext";

function toEpochMs(input) {
  if (input == null) return Date.now();
  if (typeof input === "number") return input;
  if (input instanceof Date) return input.getTime();
  if (typeof input === "string") {
    const n = Date.parse(input);
    return Number.isFinite(n) ? n : Date.now();
  }
  return Date.now();
}

function mapReading(r) {
  return {
    ts: toEpochMs(r.timestamp ?? r.ts),
    power: r.power_output ?? r.power ?? null,
    temperature: r.temperature ?? r.temp ?? null,
    humidity: r.humidity ?? r.rh ?? null,
    dust: r.dust ?? r.dust_level ?? null,
    vibration: r.vibration ?? r.vib ?? null,
    risk: r.micro_fracture_risk ?? r.microFractureRisk ?? null, // 0–1
  };
}

const Card = ({ title, children, height = 240, showGrid = true }) => (
  <div className="rounded-xl shadow-md border border-white/10 bg-white/5 p-4">
    <div className="text-xs uppercase tracking-wide text-white/60 mb-2">
      {title}
    </div>
    <div style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        {children(showGrid)}
      </ResponsiveContainer>
    </div>
  </div>
);

export default function ChartsPanel({ readings = [] }) {
  const data = useMemo(() => readings.map(mapReading), [readings]);
  const { config } = useConfig();
  const S = config?.charts ?? {
    smoothing: "monotone",
    strokeWidth: 2,
    showDots: false,
    showGrid: true,
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* 1) Power */}
      <Card title="Potencia (W)" showGrid={S.showGrid}>
        {(showGrid) => (
          <LineChart data={data}>
            {showGrid && (
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--fg) / .15)"
              />
            )}
            <XAxis
              dataKey="ts"
              tickFormatter={(t) => new Date(t).toLocaleTimeString()}
              stroke="hsl(var(--fg) / .6)"
            />
            <YAxis stroke="hsl(var(--fg) / .6)" />
            <Tooltip
              contentStyle={{ background: "rgba(0,0,0,.7)", border: "none" }}
              labelFormatter={(v) => new Date(v).toLocaleTimeString()}
            />
            <Line
              type={S.smoothing}
              dataKey="power"
              stroke="hsl(var(--chart-1))"
              strokeWidth={S.strokeWidth}
              dot={S.showDots}
              isAnimationActive={false}
            />
          </LineChart>
        )}
      </Card>

      {/* 2) Temperatura & Humedad (doble eje) */}
      <Card title="Temperatura (°C) & Humedad (%)" showGrid={S.showGrid}>
        {(showGrid) => (
          <LineChart data={data}>
            {showGrid && (
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--fg) / .15)"
              />
            )}
            <XAxis
              dataKey="ts"
              tickFormatter={(t) => new Date(t).toLocaleTimeString()}
              stroke="hsl(var(--fg) / .6)"
            />
            <YAxis yAxisId="left" stroke="hsl(var(--fg) / .6)" />
            <YAxis
              yAxisId="right"
              orientation="right"
              stroke="hsl(var(--fg) / .6)"
            />
            <Tooltip
              contentStyle={{ background: "rgba(0,0,0,.7)", border: "none" }}
              labelFormatter={(v) => new Date(v).toLocaleTimeString()}
              formatter={(val, name) => [
                val,
                name === "temperature" ? "Temperatura (°C)" : "Humedad (%)",
              ]}
            />
            <Line
              yAxisId="left"
              type={S.smoothing}
              dataKey="temperature"
              stroke="hsl(var(--chart-2))"
              strokeWidth={S.strokeWidth}
              dot={S.showDots}
              isAnimationActive={false}
            />
            <Line
              yAxisId="right"
              type={S.smoothing}
              dataKey="humidity"
              stroke="hsl(var(--chart-3))"
              strokeWidth={S.strokeWidth}
              dot={S.showDots}
              isAnimationActive={false}
            />
          </LineChart>
        )}
      </Card>

      {/* 3) Polvo */}
      <Card title="Polvo (ppm)" showGrid={S.showGrid}>
        {(showGrid) => (
          <LineChart data={data}>
            {showGrid && (
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--fg) / .15)"
              />
            )}
            <XAxis
              dataKey="ts"
              tickFormatter={(t) => new Date(t).toLocaleTimeString()}
              stroke="hsl(var(--fg) / .6)"
            />
            <YAxis stroke="hsl(var(--fg) / .6)" />
            <Tooltip
              contentStyle={{ background: "rgba(0,0,0,.7)", border: "none" }}
              labelFormatter={(v) => new Date(v).toLocaleTimeString()}
            />
            <Line
              type={S.smoothing}
              dataKey="dust"
              stroke="hsl(var(--chart-4))"
              strokeWidth={S.strokeWidth}
              dot={S.showDots}
              isAnimationActive={false}
            />
          </LineChart>
        )}
      </Card>

      {/* 4) Vibración & Riesgo (riesgo 0–1 en eje derecho) */}
      <Card
        title="Vibración (m/s²) & Riesgo de microfractura (0–1)"
        showGrid={S.showGrid}
      >
        {(showGrid) => (
          <LineChart data={data}>
            {showGrid && (
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--fg) / .15)"
              />
            )}
            <XAxis
              dataKey="ts"
              tickFormatter={(t) => new Date(t).toLocaleTimeString()}
              stroke="hsl(var(--fg) / .6)"
            />
            <YAxis yAxisId="left" stroke="hsl(var(--fg) / .6)" />
            <YAxis
              yAxisId="right"
              orientation="right"
              domain={[0, 1]}
              stroke="hsl(var(--fg) / .6)"
            />
            <Tooltip
              contentStyle={{ background: "rgba(0,0,0,.7)", border: "none" }}
              labelFormatter={(v) => new Date(v).toLocaleTimeString()}
              formatter={(val, name) => [
                val,
                name === "risk" ? "Riesgo (0–1)" : "Vibración (m/s²)",
              ]}
            />
            <Line
              yAxisId="left"
              type={S.smoothing}
              dataKey="vibration"
              stroke="hsl(var(--chart-5))"
              strokeWidth={S.strokeWidth}
              dot={S.showDots}
              isAnimationActive={false}
            />
            <Line
              yAxisId="right"
              type={S.smoothing}
              dataKey="risk"
              stroke="hsl(var(--chart-3))"
              strokeWidth={S.strokeWidth}
              dot={S.showDots}
              isAnimationActive={false}
            />
          </LineChart>
        )}
      </Card>
    </div>
  );
}
