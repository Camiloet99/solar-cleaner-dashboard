import { useUI } from "@/context/UIContext";
import { Link, NavLink } from "react-router-dom";
import { Activity, Pause } from "lucide-react";

const NavItem = ({ to, label }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `block px-3 py-2 rounded-lg text-sm transition-colors
       ${
         isActive
           ? "bg-white/10 text-white"
           : "text-white/70 hover:text-white hover:bg-white/5"
       }`
    }
  >
    {label}
  </NavLink>
);

export default function AppShell({ children }) {
  const { realtime, setRealtime, rangeMinutes, setRangeMinutes, ranges } =
    useUI();

  return (
    <div className="min-h-screen app-surface">
      {/* Topbar */}
      <header className="sticky top-0 z-30 backdrop-blur bg-zinc-950/60 border-b border-white/10">
        <div className="container mx-auto max-w-[1400px] px-4 h-14 flex items-center justify-between">
          <Link to="/" className="font-semibold tracking-tight">
            Telemetry Dashboard
          </Link>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setRealtime((v) => !v)}
              className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm border transition-colors
                ${
                  realtime
                    ? "border-emerald-400/30 bg-emerald-400/10"
                    : "border-white/20 bg-white/5 hover:bg-white/10"
                }`}
            >
              {realtime ? <Activity size={16} /> : <Pause size={16} />}
              {realtime ? "Realtime ON" : "Realtime OFF"}
            </button>

            {/* Rangos desde UIContext */}
            <div className="flex items-center gap-1">
              {(ranges ?? [5, 15, 60]).map((m) => (
                <button
                  key={m}
                  onClick={() => setRangeMinutes(m)}
                  className={`px-2.5 py-1.5 rounded-md text-xs border transition-colors
                    ${
                      rangeMinutes === m
                        ? "border-white/40 bg-white/10"
                        : "border-white/10 bg-transparent hover:bg-white/5"
                    }`}
                >
                  {m === 60 ? "1h" : `${m}m`}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto max-w-[1400px] px-4 py-6 grid grid-cols-12 gap-6">
        <aside className="col-span-12 md:col-span-3 lg:col-span-2">
          <nav className="p-3 rounded-xl bg-white/5 border border-white/10">
            <NavItem to="/" label="Dashboard" />
            <NavItem to="/sessions" label="Sesiones" />
            <NavItem to="/settings" label="Configuración" />
          </nav>
        </aside>

        <main className="col-span-12 md:col-span-9 lg:col-span-10">
          {children}
        </main>
      </div>

      <footer className="py-6 text-center text-xs text-white/50">
        <div className="container mx-auto max-w-[1400px] px-4">
          © {new Date().getFullYear()} – Telemetry
        </div>
      </footer>
    </div>
  );
}
