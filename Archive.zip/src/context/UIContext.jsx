import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useConfig } from "@/context/ConfigContext";

const UIContext = createContext(null);

export function UIProvider({ children }) {
  const { config } = useConfig();

  // Inicializa desde configuración
  const [realtime, setRealtime] = useState(
    () => config?.data?.defaultRealtime ?? true
  );
  const [rangeMinutes, setRangeMinutes] = useState(() => {
    const ranges = config?.data?.ranges ?? [5, 15, 60];
    return ranges[1] ?? ranges[0] ?? 15;
  });

  // Mantén sincronía si cambian las opciones de rango en Config:
  const ranges = useMemo(() => config?.data?.ranges ?? [5, 15, 60], [config]);
  useEffect(() => {
    // Si el rango actual ya no existe, salta al más cercano
    if (!ranges.includes(rangeMinutes)) {
      const nearest =
        [...ranges].sort(
          (a, b) => Math.abs(a - rangeMinutes) - Math.abs(b - rangeMinutes)
        )[0] ?? ranges[0];
      setRangeMinutes(nearest);
    }
  }, [ranges]); // eslint-disable-line react-hooks/exhaustive-deps

  const value = useMemo(
    () => ({
      realtime,
      setRealtime,
      rangeMinutes,
      setRangeMinutes,
      ranges, // útil para el topbar
    }),
    [realtime, rangeMinutes, ranges]
  );

  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
}

export function useUI() {
  const ctx = useContext(UIContext);
  if (!ctx) throw new Error("useUI must be used within UIProvider");
  return ctx;
}
