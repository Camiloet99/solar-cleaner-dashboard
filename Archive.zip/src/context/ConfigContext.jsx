import { createContext, useContext, useEffect, useMemo, useState } from "react";

const STORAGE_KEY = "td_config_v1";
const VERSION = 1;

const defaultConfig = {
  version: VERSION,
  general: {
    theme: "auto",
    locale: "es-CO",
    timezone: "auto",
    density: "comfortable",
  },
  data: {
    wsUrl: import.meta.env?.VITE_WS_URL || "ws://localhost:8080/ws",
    reconnect: { baseMs: 1000, maxMs: 10000, retries: 6 },
    throttleMs: 250,
    decimateEvery: 1,
    bufferMaxPoints: 600,
    ranges: [5, 15, 60], // minutos
    defaultRealtime: true,
  },
  alerts: {
    thresholds: {
      risk: 0.6,
      dust: 55,
      temperature: 70,
      humidity: 90,
      vibration: 10,
    },
    debounceMs: 2000,
    channels: { toast: true, sound: false, desktop: false },
    maxEvents: 200,
    scrollFrom: 3,
  },
  charts: {
    smoothing: "monotone", // "monotone" | "linear"
    strokeWidth: 2,
    showDots: false,
    showGrid: true,
    showLegend: false,
  },
};

function migrate(cfg) {
  // futuro: if (cfg.version === 1) { ...; cfg.version = 2 }
  return cfg;
}

function loadConfig() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultConfig;
    const parsed = JSON.parse(raw);
    return migrate({ ...defaultConfig, ...parsed }); // merge con defaults
  } catch {
    return defaultConfig;
  }
}

function saveConfig(cfg) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
}

const ConfigContext = createContext(null);

export function ConfigProvider({ children }) {
  const [config, setConfig] = useState(loadConfig);

  useEffect(() => {
    saveConfig(config);
  }, [config]);

  const value = useMemo(
    () => ({
      config,
      setConfig,
      reset: () => setConfig(defaultConfig),
      importConfig: (json) => setConfig(migrate({ ...defaultConfig, ...json })),
      exportConfig: () => JSON.stringify(config, null, 2),
    }),
    [config]
  );

  return (
    <ConfigContext.Provider value={value}>{children}</ConfigContext.Provider>
  );
}

export function useConfig() {
  const ctx = useContext(ConfigContext);
  if (!ctx) throw new Error("useConfig debe usarse dentro de ConfigProvider");
  return ctx;
}
