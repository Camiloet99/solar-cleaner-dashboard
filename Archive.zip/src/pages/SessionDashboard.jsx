// src/pages/SessionDashboard.jsx
import React, { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { Loader2 } from "lucide-react";
import {
  subscribeToSessionTelemetry,
  unsubscribeFromTelemetry,
} from "@/services/telemetryService";
import InfoPanel from "@/components/InfoPanel";
import StatusPanel from "@/components/StatusPanel";
import ChartsPanel from "@/components/ChartsPanel";
import { useUI } from "@/context/UIContext";
import useRelativeTime from "@/hooks/useRelativeTime";

const MAX_POINTS = 600; // ~20 min si recibes cada 2s

// Normaliza cualquier timestamp (number | string | Date) a epoch ms
function toEpochMs(input) {
  if (input == null) return null;
  if (typeof input === "number") return Number.isFinite(input) ? input : null;
  if (input instanceof Date)
    return Number.isFinite(input.getTime()) ? input.getTime() : null;
  if (typeof input === "string") {
    const n = Date.parse(input);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

export default function SessionDashboard() {
  const { sessionId } = useParams();
  const { realtime, rangeMinutes } = useUI();

  const [readings, setReadings] = useState([]);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  // Última lectura (para KPIs y “Actualizado …”)
  const last = readings[readings.length - 1];
  const lastTs = toEpochMs(last?.timestamp ?? last?.ts);
  const ago = useRelativeTime(lastTs);

  // Aplica rango de tiempo a la serie mostrada en charts
  const rangedReadings = useMemo(() => {
    const cutoff = Date.now() - rangeMinutes * 60_000;
    return readings.filter((r) => {
      const t = toEpochMs(r.timestamp ?? r.ts);
      return t != null && t >= cutoff;
    });
  }, [readings, rangeMinutes]);

  useEffect(() => {
    let first = true;

    const handler = (newReading) => {
      if (!realtime) return;

      // Buffer deslizante y append
      setReadings((prev) =>
        prev.length > MAX_POINTS - 1
          ? [...prev.slice(-MAX_POINTS + 1), newReading]
          : [...prev, newReading]
      );

      // Logs básicos (riesgo y polvo) con timestamps robustos
      const risk =
        newReading.micro_fracture_risk ?? newReading.microFractureRisk ?? 0;
      const dust = newReading.dust_level ?? newReading.dust ?? 0;
      const ts = toEpochMs(newReading.timestamp ?? newReading.ts) ?? Date.now();

      if (risk > 0.6) {
        setLogs((prev) => [
          {
            type: "ALERT",
            message: `High micro-fracture risk (${
              Number(risk).toFixed?.(2) ?? risk
            })`,
            timestamp: ts,
          },
          ...prev.slice(0, 19),
        ]);
      } else if (dust > 55) {
        setLogs((prev) => [
          {
            type: "INFO",
            message: `Dust level elevated: ${dust}`,
            timestamp: ts,
          },
          ...prev.slice(0, 19),
        ]);
      }

      // Oculta loader al recibir la primera lectura
      if (first) {
        first = false;
        setLoading(false);
      }
    };

    subscribeToSessionTelemetry(sessionId, handler);

    // Si en ~1.5s no llega nada, quitamos loader para mostrar estado vacío
    const fallback = setTimeout(() => setLoading(false), 1500);

    return () => {
      clearTimeout(fallback);
      try {
        unsubscribeFromTelemetry();
      } catch {}
    };
  }, [sessionId, realtime]);

  const avg = (key) => {
    const sum = readings.reduce((acc, r) => acc + (r[key] ?? 0), 0);
    return readings.length ? (sum / readings.length).toFixed(2) : "-";
  };

  return (
    <div className="space-y-6">
      {/* Header de página */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight">
            Monitoring Session:{" "}
            <span className="text-white/90">{sessionId}</span>
          </h1>
          <p className="text-sm text-white/60">Actualizado {ago}</p>
        </div>

        {/* Indicador Realtime */}
        <div className="flex items-center gap-2 text-sm">
          <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-white/40">
            <span
              className={`absolute inline-flex h-2.5 w-2.5 rounded-full ${
                realtime ? "bg-emerald-400" : "bg-white/40"
              }`}
              style={{ inset: 0 }}
            />
            {realtime && (
              <span
                className="absolute inline-flex h-2.5 w-2.5 rounded-full animate-ping bg-emerald-400/60"
                style={{ inset: 0 }}
              />
            )}
          </span>
          {realtime ? "Realtime activo" : "Realtime pausado"}
        </div>
      </div>

      {/* Contenido */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-10 w-10 text-indigo-300 animate-spin" />
        </div>
      ) : (
        <>
          <StatusPanel avg={avg} last={last} />
          <InfoPanel last={last} logs={logs} />
          <ChartsPanel readings={rangedReadings} />
        </>
      )}
    </div>
  );
}
